﻿
namespace Aim_Trainer
{
    partial class Startseite
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Startseite));
            this.lblTitel = new System.Windows.Forms.Label();
            this.btnEndM = new System.Windows.Forms.Button();
            this.btn1min = new System.Windows.Forms.Button();
            this.btn20btn = new System.Windows.Forms.Button();
            this.btnZahnrad = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTitel
            // 
            this.lblTitel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblTitel.AutoEllipsis = true;
            this.lblTitel.AutoSize = true;
            this.lblTitel.BackColor = System.Drawing.Color.Transparent;
            this.lblTitel.Font = new System.Drawing.Font("Microsoft Sans Serif", 85F);
            this.lblTitel.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblTitel.Location = new System.Drawing.Point(-20, 7);
            this.lblTitel.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.lblTitel.Name = "lblTitel";
            this.lblTitel.Size = new System.Drawing.Size(983, 161);
            this.lblTitel.TabIndex = 0;
            this.lblTitel.Text = "AIM TRAINER";
            this.lblTitel.Click += new System.EventHandler(this.lblTitel_Click);
            // 
            // btnEndM
            // 
            this.btnEndM.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnEndM.AutoSize = true;
            this.btnEndM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(40)))), ((int)(((byte)(100)))), ((int)(((byte)(120)))));
            this.btnEndM.FlatAppearance.BorderSize = 0;
            this.btnEndM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEndM.Font = new System.Drawing.Font("Microsoft Sans Serif", 45F);
            this.btnEndM.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnEndM.Location = new System.Drawing.Point(-7, 172);
            this.btnEndM.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btnEndM.Name = "btnEndM";
            this.btnEndM.Size = new System.Drawing.Size(1444, 95);
            this.btnEndM.TabIndex = 1;
            this.btnEndM.Text = "Endlos - Modus";
            this.btnEndM.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEndM.UseVisualStyleBackColor = false;
            this.btnEndM.Click += new System.EventHandler(this.btnEndM_Click);
            // 
            // btn1min
            // 
            this.btn1min.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btn1min.AutoSize = true;
            this.btn1min.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(40)))), ((int)(((byte)(100)))), ((int)(((byte)(120)))));
            this.btn1min.FlatAppearance.BorderSize = 0;
            this.btn1min.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1min.Font = new System.Drawing.Font("Microsoft Sans Serif", 45F);
            this.btn1min.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn1min.Location = new System.Drawing.Point(-7, 310);
            this.btn1min.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btn1min.Name = "btn1min";
            this.btn1min.Size = new System.Drawing.Size(1444, 95);
            this.btn1min.TabIndex = 2;
            this.btn1min.Text = "1 Minute Timer - Modus";
            this.btn1min.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn1min.UseVisualStyleBackColor = false;
            this.btn1min.Click += new System.EventHandler(this.btn1min_Click);
            // 
            // btn20btn
            // 
            this.btn20btn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btn20btn.AutoSize = true;
            this.btn20btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(40)))), ((int)(((byte)(100)))), ((int)(((byte)(120)))));
            this.btn20btn.FlatAppearance.BorderSize = 0;
            this.btn20btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn20btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 45F);
            this.btn20btn.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn20btn.Location = new System.Drawing.Point(-7, 448);
            this.btn20btn.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btn20btn.Name = "btn20btn";
            this.btn20btn.Size = new System.Drawing.Size(1444, 95);
            this.btn20btn.TabIndex = 3;
            this.btn20btn.Text = "20 Buttons - Modus";
            this.btn20btn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn20btn.UseVisualStyleBackColor = false;
            this.btn20btn.Click += new System.EventHandler(this.btn20btn_Click);
            // 
            // btnZahnrad
            // 
            this.btnZahnrad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnZahnrad.AutoSize = true;
            this.btnZahnrad.BackColor = System.Drawing.Color.Transparent;
            this.btnZahnrad.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnZahnrad.FlatAppearance.BorderSize = 0;
            this.btnZahnrad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnZahnrad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnZahnrad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZahnrad.Image = ((System.Drawing.Image)(resources.GetObject("btnZahnrad.Image")));
            this.btnZahnrad.Location = new System.Drawing.Point(1284, 362);
            this.btnZahnrad.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btnZahnrad.Name = "btnZahnrad";
            this.btnZahnrad.Size = new System.Drawing.Size(199, 181);
            this.btnZahnrad.TabIndex = 4;
            this.btnZahnrad.UseVisualStyleBackColor = false;
            this.btnZahnrad.Click += new System.EventHandler(this.btnZahnrad_Click);
            // 
            // Startseite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1496, 554);
            this.Controls.Add(this.btn20btn);
            this.Controls.Add(this.btn1min);
            this.Controls.Add(this.btnEndM);
            this.Controls.Add(this.lblTitel);
            this.Controls.Add(this.btnZahnrad);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Name = "Startseite";
            this.Text = "Startseite";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitel;
        private System.Windows.Forms.Button btnEndM;
        private System.Windows.Forms.Button btn1min;
        private System.Windows.Forms.Button btn20btn;
        private System.Windows.Forms.Button btnZahnrad;
    }
}

